"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from "recharts"
import { PieChartIcon } from "lucide-react"

interface CostBreakdownProps {
  data: Array<{ name: string; cost: number; percentage: number }>
  formatCurrency: (amount: number) => string
}

const COLORS = [
  "hsl(var(--chart-1))", // Blue
  "hsl(var(--chart-2))", // Light Blue
  "hsl(var(--chart-3))", // Sky Blue
  "hsl(var(--chart-4))", // Deep Blue
  "hsl(var(--chart-5))", // Cyan Blue
]

export function CostBreakdown({ data, formatCurrency }: CostBreakdownProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <PieChartIcon className="h-5 w-5" />
          Service Cost Breakdown
        </CardTitle>
        <CardDescription>Distribution of costs across AWS services</CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer
          config={{
            cost: {
              label: "Cost (INR)",
            },
          }}
          className="h-[300px]"
        >
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percentage }) => `${name} ${percentage}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="cost"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <ChartTooltip
                content={<ChartTooltipContent formatter={(value) => [formatCurrency(value as number), "Cost"]} />}
              />
              <Legend verticalAlign="bottom" height={36} wrapperStyle={{ fontSize: "12px" }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
