"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from "recharts"
import { TrendingUp, TrendingDown, Activity, Calendar } from "lucide-react"
import type { ParsedCsvData } from "@/lib/csv-parser"

interface TrendsSectionProps {
  formatCurrency: (amount: number) => string
  csvData?: ParsedCsvData | null
}

const defaultTrendData = [
  { month: "Jan", cost: 42000, forecast: 41000, savings: 1000 },
  { month: "Feb", cost: 38500, forecast: 42500, savings: 4000 },
  { month: "Mar", cost: 41200, forecast: 43000, savings: 1800 },
  { month: "Apr", cost: 43800, forecast: 44500, savings: 700 },
  { month: "May", cost: 45678, forecast: 46000, savings: 322 },
  { month: "Jun", cost: null, forecast: 47500, savings: 2500 },
  { month: "Jul", cost: null, forecast: 48000, savings: 3000 },
]

const optimizationTrends = [
  { category: "Reserved Instances", savings: 12500, trend: "up" },
  { category: "Spot Instances", savings: 8900, trend: "up" },
  { category: "Right Sizing", savings: 6700, trend: "down" },
  { category: "Storage Optimization", savings: 4200, trend: "up" },
]

export function TrendsSection({ formatCurrency, csvData }: TrendsSectionProps) {
  const trendData = csvData
    ? csvData.monthlyData.map((item) => ({
        month: item.month,
        cost: item.cost,
        forecast: item.cost * 1.05, // Simple 5% forecast
        savings: item.cost * 0.1, // Potential 10% savings
      }))
    : defaultTrendData

  const avgGrowth = csvData ? csvData.monthlyChange : 2.3
  const potentialSavings = csvData ? csvData.totalCost * 0.15 : 32200
  const volatility = csvData
    ? csvData.monthlyData.length > 1
      ? (Math.abs(csvData.monthlyData[csvData.monthlyData.length - 1].cost - csvData.monthlyData[0].cost) /
          csvData.monthlyData[0].cost) *
        100
      : 8.5
    : 8.5

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Cost Trends & Forecasting</h2>
          <p className="text-muted-foreground">
            {csvData
              ? `Analyzing ${csvData.rawData.length} records from uploaded data`
              : "Analyze spending patterns and predict future costs"}
          </p>
        </div>
        <Badge variant="outline" className="flex items-center gap-1">
          <Calendar className="h-3 w-3" />
          {csvData ? `${csvData.monthlyData.length}-Month View` : "6-Month View"}
        </Badge>
      </div>

      {/* Trend Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Monthly Growth</CardTitle>
            <TrendingUp className={`h-4 w-4 ${avgGrowth > 0 ? "text-red-500" : "text-green-500"}`} />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${avgGrowth > 0 ? "text-red-500" : "text-green-500"}`}>
              {avgGrowth > 0 ? "+" : ""}
              {avgGrowth.toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground">{csvData ? "From uploaded data" : "Last 6 months"}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Potential Savings</CardTitle>
            <TrendingDown className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-500">{formatCurrency(potentialSavings)}</div>
            <p className="text-xs text-muted-foreground">Next quarter</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Cost Volatility</CardTitle>
            <Activity className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-500">
              {volatility > 15 ? "High" : volatility > 8 ? "Medium" : "Low"}
            </div>
            <p className="text-xs text-muted-foreground">±{volatility.toFixed(1)}% variance</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Data Quality</CardTitle>
            <TrendingUp className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-500">{csvData ? "100%" : "94.2%"}</div>
            <p className="text-xs text-muted-foreground">{csvData ? "Live data" : "Last 3 months"}</p>
          </CardContent>
        </Card>
      </div>

      {/* Cost Trend Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Cost Trends & Forecast</CardTitle>
          <CardDescription>
            {csvData
              ? "Actual spending from your uploaded data with forecasted trends"
              : "Actual vs forecasted spending with optimization opportunities"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <AreaChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis tickFormatter={(value) => `₹${(value / 1000).toFixed(0)}K`} />
              <Tooltip
                formatter={(value: number, name: string) => [formatCurrency(value), name]}
                labelFormatter={(label) => `Month: ${label}`}
              />
              <Area
                type="monotone"
                dataKey="cost"
                stackId="1"
                stroke="#3b82f6"
                fill="#3b82f6"
                fillOpacity={0.6}
                name="Actual Cost"
              />
              <Area
                type="monotone"
                dataKey="forecast"
                stackId="2"
                stroke="#60a5fa"
                fill="#60a5fa"
                fillOpacity={0.3}
                name="Forecast"
                strokeDasharray="5 5"
              />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Optimization Trends */}
      <Card>
        <CardHeader>
          <CardTitle>Optimization Trends</CardTitle>
          <CardDescription>Track savings opportunities across different categories</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {optimizationTrends.map((item, index) => (
              <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div
                    className={`p-2 rounded-full ${item.trend === "up" ? "bg-green-100 text-green-600" : "bg-red-100 text-red-600"}`}
                  >
                    {item.trend === "up" ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                  </div>
                  <div>
                    <p className="font-medium">{item.category}</p>
                    <p className="text-sm text-muted-foreground">Monthly savings potential</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-lg">{formatCurrency(item.savings)}</p>
                  <Badge variant={item.trend === "up" ? "default" : "destructive"} className="text-xs">
                    {item.trend === "up" ? "Increasing" : "Decreasing"}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
