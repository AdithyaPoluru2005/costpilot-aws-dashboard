"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileText, Download, Calendar, AlertCircle, CheckCircle, Clock } from "lucide-react"
import type { ParsedCsvData } from "@/lib/csv-parser"

interface ReportsSectionProps {
  formatCurrency: (amount: number) => string
  csvData?: ParsedCsvData | null
}

const defaultReports = [
  {
    id: 1,
    title: "Monthly Cost Analysis",
    description: "Comprehensive breakdown of monthly AWS spending",
    type: "Monthly",
    status: "completed",
    generatedDate: "2024-01-15",
    size: "2.4 MB",
    insights: 12,
    savings: 8500,
  },
  {
    id: 2,
    title: "Service Optimization Report",
    description: "Recommendations for optimizing AWS service usage",
    type: "Optimization",
    status: "completed",
    generatedDate: "2024-01-14",
    size: "1.8 MB",
    insights: 8,
    savings: 15200,
  },
  {
    id: 3,
    title: "Quarterly Forecast",
    description: "Cost projections and budget planning for Q2 2024",
    type: "Forecast",
    status: "processing",
    generatedDate: "2024-01-16",
    size: "3.1 MB",
    insights: 15,
    savings: 22000,
  },
  {
    id: 4,
    title: "Security & Compliance Audit",
    description: "Cost implications of security and compliance measures",
    type: "Audit",
    status: "scheduled",
    generatedDate: "2024-01-18",
    size: "1.2 MB",
    insights: 6,
    savings: 4500,
  },
]

const scheduledReports = [
  { name: "Weekly Cost Summary", frequency: "Weekly", nextRun: "2024-01-22", enabled: true },
  { name: "Monthly Optimization", frequency: "Monthly", nextRun: "2024-02-01", enabled: true },
  { name: "Quarterly Forecast", frequency: "Quarterly", nextRun: "2024-04-01", enabled: false },
  { name: "Annual Budget Review", frequency: "Yearly", nextRun: "2024-12-31", enabled: true },
]

const defaultInsights = [
  {
    title: "Reserved Instance Opportunities",
    description: "Switch to Reserved Instances for EC2 workloads",
    impact: "High",
    savings: 12500,
    category: "Cost Optimization",
  },
  {
    title: "Unused EBS Volumes",
    description: "14 unattached EBS volumes detected",
    impact: "Medium",
    savings: 3200,
    category: "Resource Cleanup",
  },
  {
    title: "Right-sizing Recommendations",
    description: "Over-provisioned instances identified",
    impact: "High",
    savings: 8900,
    category: "Performance",
  },
  {
    title: "Storage Class Optimization",
    description: "Move infrequently accessed data to cheaper storage",
    impact: "Medium",
    savings: 5600,
    category: "Storage",
  },
]

export function ReportsSection({ formatCurrency, csvData }: ReportsSectionProps) {
  const reports = csvData
    ? [
        {
          id: 1,
          title: "Uploaded Data Analysis",
          description: `Analysis of ${csvData.rawData.length} cost records from uploaded CSV`,
          type: "Custom",
          status: "completed",
          generatedDate: new Date().toISOString().split("T")[0],
          size: "Live Data",
          insights: csvData.services.length,
          savings: csvData.totalCost * 0.15, // 15% potential savings
        },
        {
          id: 2,
          title: "Service Breakdown Report",
          description: `Detailed analysis of ${csvData.services.length} AWS services`,
          type: "Service Analysis",
          status: "completed",
          generatedDate: new Date().toISOString().split("T")[0],
          size: "Live Data",
          insights: Math.min(csvData.services.length * 2, 20),
          savings: csvData.totalCost * 0.12,
        },
        {
          id: 3,
          title: "Monthly Trends Report",
          description: `Cost trends across ${csvData.monthlyData.length} months`,
          type: "Trends",
          status: "completed",
          generatedDate: new Date().toISOString().split("T")[0],
          size: "Live Data",
          insights: csvData.monthlyData.length + 5,
          savings: Math.abs(csvData.monthlyChange) > 10 ? csvData.totalCost * 0.2 : csvData.totalCost * 0.08,
        },
        ...defaultReports.slice(3), // Keep some default reports
      ]
    : defaultReports

  const insights = csvData
    ? [
        {
          title: "Top Cost Driver Optimization",
          description: `${csvData.services[0]?.name || "Top service"} accounts for ${csvData.services[0]?.percentage.toFixed(1) || "0"}% of total costs`,
          impact:
            csvData.services[0]?.percentage > 40 ? "High" : csvData.services[0]?.percentage > 20 ? "Medium" : "Low",
          savings: csvData.services[0]?.cost * 0.2 || 0,
          category: "Cost Optimization",
        },
        {
          title: "Service Consolidation",
          description: `${csvData.services.length} services detected - consolidation opportunities available`,
          impact: csvData.services.length > 10 ? "High" : "Medium",
          savings: csvData.totalCost * 0.08,
          category: "Resource Optimization",
        },
        {
          title: "Monthly Growth Analysis",
          description: `${csvData.monthlyChange > 0 ? "Increasing" : "Decreasing"} trend of ${Math.abs(csvData.monthlyChange).toFixed(1)}% detected`,
          impact:
            Math.abs(csvData.monthlyChange) > 15 ? "High" : Math.abs(csvData.monthlyChange) > 5 ? "Medium" : "Low",
          savings: Math.abs(csvData.monthlyChange) > 10 ? csvData.totalCost * 0.15 : csvData.totalCost * 0.05,
          category: "Trend Analysis",
        },
        {
          title: "Data-Driven Recommendations",
          description: `Based on ${csvData.rawData.length} records, multiple optimization opportunities identified`,
          impact: "Medium",
          savings: csvData.totalCost * 0.1,
          category: "Analytics",
        },
      ]
    : defaultInsights

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800"
      case "processing":
        return "bg-blue-100 text-blue-800"
      case "scheduled":
        return "bg-orange-100 text-orange-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return CheckCircle
      case "processing":
        return Clock
      case "scheduled":
        return Calendar
      default:
        return AlertCircle
    }
  }

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case "High":
        return "bg-red-100 text-red-800"
      case "Medium":
        return "bg-orange-100 text-orange-800"
      case "Low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Reports & Analytics</h2>
          <p className="text-muted-foreground">
            {csvData
              ? `Generate reports from your uploaded data (${csvData.rawData.length} records)`
              : "Generate and manage cost optimization reports"}
          </p>
        </div>
        <Button>
          <FileText className="h-4 w-4 mr-2" />
          Generate New Report
        </Button>
      </div>

      <Tabs defaultValue="reports" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="reports">Generated Reports</TabsTrigger>
          <TabsTrigger value="scheduled">Scheduled Reports</TabsTrigger>
          <TabsTrigger value="insights">Key Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="reports" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {reports.map((report) => {
              const StatusIcon = getStatusIcon(report.status)

              return (
                <Card key={report.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-primary/10 rounded-lg">
                          <FileText className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{report.title}</CardTitle>
                          <CardDescription>{report.description}</CardDescription>
                        </div>
                      </div>
                      <Badge className={getStatusColor(report.status)}>
                        <StatusIcon className="h-3 w-3 mr-1" />
                        {report.status}
                      </Badge>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Generated</p>
                        <p className="font-medium">{new Date(report.generatedDate).toLocaleDateString()}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Data Source</p>
                        <p className="font-medium">{report.size}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Insights</p>
                        <p className="font-medium">{report.insights} recommendations</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Potential Savings</p>
                        <p className="font-medium text-green-600">{formatCurrency(report.savings)}</p>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                      <Button size="sm" variant="ghost" className="flex-1">
                        View Details
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        <TabsContent value="scheduled" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Automated Report Schedule</CardTitle>
              <CardDescription>Manage your recurring cost analysis reports</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {scheduledReports.map((report, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div
                        className={`p-2 rounded-full ${report.enabled ? "bg-green-100 text-green-600" : "bg-gray-100 text-gray-600"}`}
                      >
                        <Calendar className="h-4 w-4" />
                      </div>
                      <div>
                        <p className="font-medium">{report.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {report.frequency} • Next: {new Date(report.nextRun).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={report.enabled ? "default" : "secondary"}>
                        {report.enabled ? "Enabled" : "Disabled"}
                      </Badge>
                      <Button size="sm" variant="ghost">
                        Configure
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {insights.map((insight, index) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{insight.title}</CardTitle>
                      <CardDescription>{insight.description}</CardDescription>
                    </div>
                    <Badge className={getImpactColor(insight.impact)}>{insight.impact} Impact</Badge>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Potential Monthly Savings</p>
                      <p className="text-2xl font-bold text-green-600">{formatCurrency(insight.savings)}</p>
                    </div>
                    <Badge variant="outline">{insight.category}</Badge>
                  </div>

                  <div className="flex gap-2">
                    <Button size="sm" className="flex-1">
                      Implement
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                      Learn More
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
