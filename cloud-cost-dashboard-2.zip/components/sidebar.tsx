"use client"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { LayoutDashboard, BarChart3, PieChart, Settings, FileText, TrendingUp, DollarSign } from "lucide-react"

interface SidebarProps {
  activeSection: string
  onSectionChange: (section: string) => void
}

const sidebarItems = [
  {
    id: "overview",
    label: "Overview",
    icon: LayoutDashboard,
  },
  {
    id: "analytics",
    label: "Analytics",
    icon: BarChart3,
  },
  {
    id: "trends",
    label: "Trends",
    icon: TrendingUp,
  },
  {
    id: "services",
    label: "Services",
    icon: PieChart,
  },
  {
    id: "reports",
    label: "Reports",
    icon: FileText,
  },
  {
    id: "settings",
    label: "Settings",
    icon: Settings,
  },
]

export function Sidebar({ activeSection, onSectionChange }: SidebarProps) {
  return (
    <div className="w-64 bg-sidebar border-r border-sidebar-border">
      <div className="p-6">
        <div className="flex items-center gap-2 mb-8">
          <DollarSign className="h-8 w-8 text-sidebar-primary" />
          <div>
            <h2 className="text-lg font-bold text-sidebar-foreground">Cost Optimizer</h2>
            <p className="text-xs text-sidebar-foreground/60">AWS Dashboard</p>
          </div>
        </div>

        <nav className="space-y-2">
          {sidebarItems.map((item) => {
            const Icon = item.icon
            return (
              <Button
                key={item.id}
                variant={activeSection === item.id ? "default" : "ghost"}
                className={cn(
                  "w-full justify-start gap-3 text-sidebar-foreground",
                  activeSection === item.id && "bg-sidebar-accent text-sidebar-accent-foreground",
                )}
                onClick={() => onSectionChange(item.id)}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Button>
            )
          })}
        </nav>
      </div>
    </div>
  )
}
