"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts"
import { Server, Database, Globe, Zap, Settings, AlertTriangle, CheckCircle, Cloud } from "lucide-react"
import type { ParsedCsvData } from "@/lib/csv-parser"

interface ServicesSectionProps {
  formatCurrency: (amount: number) => string
  csvData?: ParsedCsvData | null
}

const defaultServiceDetails = [
  {
    name: "EC2",
    icon: Server,
    cost: 18500.45,
    percentage: 40.5,
    instances: 24,
    status: "optimized",
    recommendations: 2,
    description: "Elastic Compute Cloud instances",
    monthlyTrend: "+5.2%",
  },
  {
    name: "S3",
    icon: Database,
    cost: 8900.23,
    percentage: 19.5,
    instances: 156,
    status: "warning",
    recommendations: 4,
    description: "Simple Storage Service",
    monthlyTrend: "+12.8%",
  },
  {
    name: "RDS",
    icon: Database,
    cost: 7800.12,
    percentage: 17.1,
    instances: 8,
    status: "critical",
    recommendations: 6,
    description: "Relational Database Service",
    monthlyTrend: "+18.3%",
  },
  {
    name: "Lambda",
    icon: Zap,
    cost: 5600.78,
    percentage: 12.3,
    instances: 342,
    status: "optimized",
    recommendations: 1,
    description: "Serverless compute functions",
    monthlyTrend: "-2.1%",
  },
  {
    name: "CloudFront",
    icon: Globe,
    cost: 4877.32,
    percentage: 10.6,
    instances: 12,
    status: "optimized",
    recommendations: 0,
    description: "Content Delivery Network",
    monthlyTrend: "+3.7%",
  },
]

const COLORS = [
  "hsl(var(--chart-1))", // Blue
  "hsl(var(--chart-2))", // Light Blue
  "hsl(var(--chart-3))", // Sky Blue
  "hsl(var(--chart-4))", // Deep Blue
  "hsl(var(--chart-5))", // Cyan Blue
]

const getServiceIcon = (serviceName: string) => {
  const name = serviceName.toLowerCase()
  if (name.includes("ec2") || name.includes("compute")) return Server
  if (name.includes("s3") || name.includes("storage") || name.includes("rds") || name.includes("database"))
    return Database
  if (name.includes("cloudfront") || name.includes("cdn")) return Globe
  if (name.includes("lambda") || name.includes("function")) return Zap
  return Cloud
}

export function ServicesSection({ formatCurrency, csvData }: ServicesSectionProps) {
  const serviceDetails = csvData
    ? csvData.services.map((service, index) => ({
        name: service.name,
        icon: getServiceIcon(service.name),
        cost: service.cost,
        percentage: service.percentage,
        instances: Math.floor(Math.random() * 100) + 1, // Simulated instance count
        status: service.percentage > 30 ? "critical" : service.percentage > 15 ? "warning" : "optimized",
        recommendations: service.percentage > 20 ? Math.floor(Math.random() * 5) + 1 : Math.floor(Math.random() * 2),
        description: `AWS ${service.name} service`,
        monthlyTrend: `${Math.random() > 0.5 ? "+" : "-"}${(Math.random() * 20).toFixed(1)}%`,
      }))
    : defaultServiceDetails

  const getStatusColor = (status: string) => {
    switch (status) {
      case "optimized":
        return "text-green-500 bg-green-100"
      case "warning":
        return "text-orange-500 bg-orange-100"
      case "critical":
        return "text-red-500 bg-red-100"
      default:
        return "text-gray-500 bg-gray-100"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "optimized":
        return CheckCircle
      case "warning":
        return AlertTriangle
      case "critical":
        return AlertTriangle
      default:
        return Settings
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">AWS Services Overview</h2>
          <p className="text-muted-foreground">
            {csvData
              ? `Analyzing ${csvData.services.length} services from uploaded data`
              : "Detailed breakdown of your AWS service usage and costs"}
          </p>
        </div>
        <Button variant="outline">
          <Settings className="h-4 w-4 mr-2" />
          Configure Services
        </Button>
      </div>

      {/* Service Distribution Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Cost Distribution</CardTitle>
            <CardDescription>Service-wise cost breakdown</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={serviceDetails}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percentage }) => `${name} ${percentage.toFixed(1)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="cost"
                >
                  {serviceDetails.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => formatCurrency(value)} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Monthly Cost Comparison</CardTitle>
            <CardDescription>Service costs over time</CardDescription>
          </CardHeader>
          <CardContent className="w-full overflow-x-auto">
            <ResponsiveContainer width="100%" height={300} minWidth={300}>
              <BarChart data={serviceDetails} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis tickFormatter={(value) => `₹${(value / 1000).toFixed(0)}K`} />
                <Tooltip formatter={(value: number) => formatCurrency(value)} />
                <Bar dataKey="cost" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Service Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {serviceDetails.slice(0, 6).map((service, index) => {
          const Icon = service.icon
          const StatusIcon = getStatusIcon(service.status)

          return (
            <Card key={service.name} className="relative">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{service.name}</CardTitle>
                      <CardDescription className="text-xs">{service.description}</CardDescription>
                    </div>
                  </div>
                  <div className={`p-1 rounded-full ${getStatusColor(service.status)}`}>
                    <StatusIcon className="h-4 w-4" />
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold">{formatCurrency(service.cost)}</span>
                  <Badge variant={service.monthlyTrend.startsWith("+") ? "destructive" : "default"}>
                    {service.monthlyTrend}
                  </Badge>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Usage: {service.instances} instances</span>
                    <span>{service.percentage.toFixed(1)}% of total</span>
                  </div>
                  <Progress value={Math.min(service.percentage * 2, 100)} className="h-2" />
                </div>

                {service.recommendations > 0 && (
                  <div className="flex items-center justify-between p-2 bg-muted rounded-lg">
                    <span className="text-sm text-muted-foreground">
                      {service.recommendations} optimization{service.recommendations > 1 ? "s" : ""} available
                    </span>
                    <Button size="sm" variant="ghost">
                      View
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
