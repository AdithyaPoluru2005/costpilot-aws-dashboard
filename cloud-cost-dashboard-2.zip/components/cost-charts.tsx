"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Bar, BarChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts"
import { BarChart3 } from "lucide-react"

interface CostChartsProps {
  data: {
    services: Array<{ name: string; cost: number; percentage: number }>
    monthlyData: Array<{ month: string; cost: number }>
  }
  formatCurrency: (amount: number) => string
}

export function CostCharts({ data, formatCurrency }: CostChartsProps) {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Service Cost Analysis
          </CardTitle>
          <CardDescription>Detailed breakdown of costs by AWS service</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              cost: {
                label: "Cost (INR)",
                color: "#3b82f6",
              },
            }}
            className="h-[400px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.services} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="name" className="text-muted-foreground" tick={{ fontSize: 12 }} />
                <YAxis
                  className="text-muted-foreground"
                  tick={{ fontSize: 12 }}
                  tickFormatter={(value) => `₹${(value / 1000).toFixed(0)}K`}
                />
                <ChartTooltip
                  content={<ChartTooltipContent formatter={(value) => [formatCurrency(value as number), "Cost"]} />}
                />
                <Bar dataKey="cost" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>
    </div>
  )
}
