export interface CsvRow {
  service: string
  cost: number
  date: string
  region?: string
  usageType?: string
  [key: string]: any
}

export interface ParsedCsvData {
  totalCost: number
  monthlyChange: number
  services: Array<{
    name: string
    cost: number
    percentage: number
  }>
  monthlyData: Array<{
    month: string
    cost: number
  }>
  rawData: CsvRow[]
}

export function parseCSV(csvContent: string): ParsedCsvData {
  const lines = csvContent.trim().split("\n")
  const headers = lines[0].split(",").map((h) => h.trim().toLowerCase().replace(/"/g, ""))

  console.log("[v0] CSV Headers:", headers)

  const serviceIndex = headers.findIndex(
    (h) =>
      h.includes("service") ||
      h.includes("product") ||
      h.includes("productname") ||
      h.includes("industry_name") ||
      h.includes("variable_name") ||
      h.includes("description"),
  )
  const costIndex = headers.findIndex(
    (h) =>
      h.includes("cost") ||
      h.includes("amount") ||
      h.includes("charge") ||
      h.includes("blendedcost") ||
      h.includes("value") ||
      h.includes("total"),
  )
  const dateIndex = headers.findIndex(
    (h) => h.includes("date") || h.includes("time") || h.includes("period") || h.includes("year"),
  )

  console.log("[v0] Found indices - Service:", serviceIndex, "Cost:", costIndex, "Date:", dateIndex)

  const rawData: CsvRow[] = []

  // Parse data rows
  for (let i = 1; i < lines.length; i++) {
    const values = parseCSVLine(lines[i])

    if (values.length > Math.max(serviceIndex, costIndex, dateIndex)) {
      const service = serviceIndex >= 0 ? values[serviceIndex] : `Item ${i}`
      const costStr = costIndex >= 0 ? values[costIndex] : "0"
      const dateStr = dateIndex >= 0 ? values[dateIndex] : new Date().getFullYear().toString()

      // Parse cost (handle different formats)
      let cost = 0
      const cleanCostStr = costStr.replace(/[₹$,]/g, "")
      if (!isNaN(Number.parseFloat(cleanCostStr))) {
        cost = Number.parseFloat(cleanCostStr)
      }

      if (service && service.trim() !== "") {
        rawData.push({
          service: service.trim(),
          cost: Math.abs(cost), // Use absolute value for costs
          date: dateStr,
          usageType: values[headers.findIndex((h) => h.includes("usage") || h.includes("category"))] || "",
          region: values[headers.findIndex((h) => h.includes("region") || h.includes("location"))] || "",
        })
      }
    }
  }

  console.log("[v0] Parsed raw data:", rawData.slice(0, 5))

  // Calculate total cost
  const totalCost = rawData.reduce((sum, row) => sum + row.cost, 0)

  // Group by service
  const serviceMap = new Map<string, number>()
  rawData.forEach((row) => {
    const current = serviceMap.get(row.service) || 0
    serviceMap.set(row.service, current + row.cost)
  })

  // Convert to services array with percentages
  const services = Array.from(serviceMap.entries())
    .map(([name, cost]) => ({
      name,
      cost,
      percentage: totalCost > 0 ? (cost / totalCost) * 100 : 0,
    }))
    .sort((a, b) => b.cost - a.cost)
    .slice(0, 10) // Top 10 services

  const monthMap = new Map<string, number>()
  rawData.forEach((row) => {
    let monthKey: string

    // Handle different date formats
    if (row.date.includes("-") || row.date.includes("/")) {
      const date = new Date(row.date)
      monthKey = date.toLocaleDateString("en-US", { month: "short", year: "numeric" })
    } else if (row.date.length === 4) {
      // Year only
      monthKey = `${row.date}`
    } else {
      monthKey = new Date().toLocaleDateString("en-US", { month: "short", year: "numeric" })
    }

    const current = monthMap.get(monthKey) || 0
    monthMap.set(monthKey, current + row.cost)
  })

  const monthlyData = Array.from(monthMap.entries())
    .map(([month, cost]) => ({ month, cost }))
    .sort((a, b) => {
      // Sort by year first, then month
      const aYear = a.month.includes(" ") ? Number.parseInt(a.month.split(" ")[1]) : Number.parseInt(a.month)
      const bYear = b.month.includes(" ") ? Number.parseInt(b.month.split(" ")[1]) : Number.parseInt(b.month)
      return aYear - bYear
    })

  // Calculate monthly change (simplified)
  const monthlyChange =
    monthlyData.length >= 2
      ? ((monthlyData[monthlyData.length - 1].cost - monthlyData[monthlyData.length - 2].cost) /
          Math.max(monthlyData[monthlyData.length - 2].cost, 1)) *
        100
      : 0

  console.log("[v0] Processed data:", { totalCost, services: services.slice(0, 3), monthlyData })

  return {
    totalCost,
    monthlyChange,
    services,
    monthlyData,
    rawData,
  }
}

function parseCSVLine(line: string): string[] {
  const result: string[] = []
  let current = ""
  let inQuotes = false

  for (let i = 0; i < line.length; i++) {
    const char = line[i]

    if (char === '"') {
      inQuotes = !inQuotes
    } else if (char === "," && !inQuotes) {
      result.push(current.trim())
      current = ""
    } else {
      current += char
    }
  }

  result.push(current.trim())
  return result
}
