"use client"

import { useState, useCallback } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Sidebar } from "@/components/sidebar"
import { FileUpload } from "@/components/file-upload"
import { CostCharts } from "@/components/cost-charts"
import { MonthlyTrends } from "@/components/monthly-trends"
import { CostBreakdown } from "@/components/cost-breakdown"
import { TrendsSection } from "@/components/trends-section"
import { ServicesSection } from "@/components/services-section"
import { ReportsSection } from "@/components/reports-section"
import { SettingsSection } from "@/components/settings-section"
import { Upload, DollarSign, TrendingUp, BarChart3 } from "lucide-react"
import { parseCSV, type ParsedCsvData } from "@/lib/csv-parser"

// Sample data for demonstration
const sampleData = {
  totalCost: 45678.9,
  monthlyChange: 12.5,
  services: [
    { name: "EC2", cost: 18500.45, percentage: 40.5 },
    { name: "S3", cost: 8900.23, percentage: 19.5 },
    { name: "RDS", cost: 7800.12, percentage: 17.1 },
    { name: "Lambda", cost: 5600.78, percentage: 12.3 },
    { name: "CloudFront", cost: 4877.32, percentage: 10.6 },
  ],
  monthlyData: [
    { month: "Jan", cost: 42000 },
    { month: "Feb", cost: 38500 },
    { month: "Mar", cost: 41200 },
    { month: "Apr", cost: 43800 },
    { month: "May", cost: 45678 },
  ],
}

export default function Dashboard() {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [activeSection, setActiveSection] = useState("overview")
  const [csvData, setCsvData] = useState<ParsedCsvData | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const handleFileUpload = useCallback(async (file: File | null) => {
    setUploadedFile(file)

    if (file) {
      setIsLoading(true)
      try {
        const text = await file.text()
        console.log("[v0] CSV file content preview:", text.substring(0, 500))
        const parsedData = parseCSV(text)
        setCsvData(parsedData)
        console.log("[v0] Successfully parsed CSV data:", parsedData)
      } catch (error) {
        console.error("[v0] Error parsing CSV:", error)
        setCsvData(null)
      } finally {
        setIsLoading(false)
      }
    } else {
      setCsvData(null)
    }
  }, [])

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      minimumFractionDigits: 2,
    }).format(amount)
  }

  const displayData = csvData || sampleData

  const renderSectionContent = () => {
    switch (activeSection) {
      case "overview":
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <MonthlyTrends data={displayData.monthlyData} formatCurrency={formatCurrency} />
            <CostBreakdown data={displayData.services} formatCurrency={formatCurrency} />
          </div>
        )
      case "analytics":
        return <CostCharts data={displayData} formatCurrency={formatCurrency} />
      case "trends":
        return <TrendsSection formatCurrency={formatCurrency} csvData={csvData} />
      case "services":
        return <ServicesSection formatCurrency={formatCurrency} csvData={csvData} />
      case "reports":
        return <ReportsSection formatCurrency={formatCurrency} csvData={csvData} />
      case "settings":
        return <SettingsSection formatCurrency={formatCurrency} />
      default:
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <MonthlyTrends data={displayData.monthlyData} formatCurrency={formatCurrency} />
            <CostBreakdown data={displayData.services} formatCurrency={formatCurrency} />
          </div>
        )
    }
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar activeSection={activeSection} onSectionChange={setActiveSection} />

      <main className="flex-1 overflow-auto p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Cloud Cost Dashboard</h1>
              <p className="text-muted-foreground">Monitor and optimize your AWS spending</p>
            </div>
            <div className="flex items-center gap-2">
              {csvData && (
                <Badge variant="default" className="text-sm">
                  Using uploaded data
                </Badge>
              )}
              <Badge variant="secondary" className="text-sm">
                Last updated: {new Date().toLocaleDateString()}
              </Badge>
            </div>
          </div>

          {/* File Upload Section */}
          {activeSection === "overview" && (
            <>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Upload className="h-5 w-5" />
                    Upload AWS Usage Data
                  </CardTitle>
                  <CardDescription>Upload your AWS billing CSV file to analyze cost patterns</CardDescription>
                </CardHeader>
                <CardContent>
                  <FileUpload onFileUpload={handleFileUpload} />
                  {isLoading && (
                    <div className="mt-4 p-3 bg-muted rounded-lg">
                      <p className="text-sm text-muted-foreground">Processing CSV file...</p>
                    </div>
                  )}
                  {uploadedFile && csvData && (
                    <div className="mt-4 p-3 bg-green-50 dark:bg-green-950 rounded-lg border border-green-200 dark:border-green-800">
                      <p className="text-sm text-green-700 dark:text-green-300">
                        ✓ Successfully processed: <span className="font-medium">{uploadedFile.name}</span>
                      </p>
                      <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                        Found {csvData.rawData.length} records, {csvData.services.length} services
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Overview Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Monthly Cost</CardTitle>
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{formatCurrency(displayData.totalCost)}</div>
                    <p className="text-xs text-muted-foreground">
                      {displayData.monthlyChange > 0 ? "+" : ""}
                      {displayData.monthlyChange.toFixed(1)}% from last month
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Top Service</CardTitle>
                    <BarChart3 className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{displayData.services[0]?.name || "N/A"}</div>
                    <p className="text-xs text-muted-foreground">
                      {displayData.services[0]
                        ? `${formatCurrency(displayData.services[0].cost)} (${displayData.services[0].percentage.toFixed(1)}%)`
                        : "No data"}
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Cost Trend</CardTitle>
                    <TrendingUp className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div
                      className={`text-2xl font-bold ${displayData.monthlyChange > 0 ? "text-red-500" : "text-green-500"}`}
                    >
                      {displayData.monthlyChange > 0 ? "Increasing" : "Optimizing"}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {csvData ? `${csvData.rawData.length} records analyzed` : "3 recommendations available"}
                    </p>
                  </CardContent>
                </Card>
              </div>
            </>
          )}

          {renderSectionContent()}
        </div>
      </main>
    </div>
  )
}
